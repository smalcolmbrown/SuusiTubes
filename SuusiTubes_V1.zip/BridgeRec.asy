Version 4
SymbolType BLOCK
LINE Normal 16 -16 -16 0
LINE Normal 16 16 16 -16
LINE Normal -16 0 16 16
LINE Normal -48 0 -16 0
LINE Normal 16 0 48 0
LINE Normal -16 16 -16 -16
RECTANGLE Normal 80 80 -80 -80
WINDOW 38 1 32 Center 2
SYMATTR SpiceModel BridgeRec
SYMATTR Prefix X
PIN 0 -80 TOP 8
PINATTR PinName ~
PINATTR SpiceOrder 1
PIN 0 80 BOTTOM 8
PINATTR PinName ~
PINATTR SpiceOrder 2
PIN -80 0 LEFT 8
PINATTR PinName +
PINATTR SpiceOrder 3
PIN 80 0 RIGHT 8
PINATTR PinName -
PINATTR SpiceOrder 4
