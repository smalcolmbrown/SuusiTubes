Version 4
SymbolType BLOCK
LINE Normal 16 96 96 96
LINE Normal 16 96 16 96
LINE Normal 16 0 96 0
LINE Normal -24 -112 -24 112 1
LINE Normal -16 -112 -16 112 1
LINE Normal -32 -112 -32 112 1
LINE Normal 96 -96 16 -96
LINE Normal -40 -112 -40 112 1
RECTANGLE Normal -64 -128 80 128
ARC Normal 32 32 0 0 16 0 16 32
ARC Normal 32 0 0 -32 16 -32 16 0
ARC Normal 32 64 0 32 16 32 16 64
ARC Normal 32 -32 0 -64 16 -64 16 -32
ARC Normal 32 -64 0 -96 16 -96 16 -64
ARC Normal 32 96 0 64 16 64 16 96
TEXT 32 48 Center 2 Lb
TEXT 32 -48 Center 2 La
WINDOW 0 0 -144 Center 2
WINDOW 38 0 144 Center 2
SYMATTR SpiceModel TappedInductor
SYMATTR Prefix X
PIN 96 96 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 96 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 96 -96 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
