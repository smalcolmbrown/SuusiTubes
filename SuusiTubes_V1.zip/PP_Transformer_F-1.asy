Version 4
SymbolType CELL
LINE Normal -32 -192 -128 -192
LINE Normal -32 -192 -32 -192
LINE Normal -32 0 -128 0
LINE Normal -32 192 -127 192
LINE Normal 32 -64 128 -64
LINE Normal 32 64 128 64
LINE Normal -8 208 -8 -208 1
LINE Normal 0 208 0 -208 1
LINE Normal 7 208 7 -208 1
LINE Normal 32 -128 32 -128
RECTANGLE Normal 112 240 -112 -240
CIRCLE Normal -48 -176 -32 -192
CIRCLE Normal -35 -189 -45 -179
CIRCLE Normal 32 -48 48 -64
CIRCLE Normal 45 -61 35 -51
ARC Normal 16 32 48 64 32 32 32 64
ARC Normal 16 0 48 32 32 0 32 32
ARC Normal 16 -32 48 0 32 -32 32 0
ARC Normal -16 -64 -48 -32 -32 -32 -32 -64
ARC Normal -16 -96 -48 -64 -32 -64 -32 -96
ARC Normal -16 -128 -48 -96 -32 -96 -32 -128
ARC Normal -16 96 -48 128 -32 128 -32 96
ARC Normal -16 64 -48 96 -32 96 -32 64
ARC Normal -16 32 -48 64 -32 64 -32 32
ARC Normal 16 -64 48 -32 32 -64 32 -32
ARC Normal -16 -160 -48 -128 -32 -128 -32 -160
ARC Normal -16 128 -48 160 -32 160 -32 128
ARC Normal -16 -32 -48 0 -32 0 -32 -32
ARC Normal -16 0 -48 32 -32 32 -32 0
ARC Normal -16 -192 -48 -160 -32 -160 -32 -192
ARC Normal -16 160 -48 192 -32 192 -32 160
WINDOW 0 0 -272 Center 2
WINDOW 38 0 272 Center 2
SYMATTR SpiceModel PP_Transformer_F-1
SYMATTR Prefix X
SYMATTR Description Fender style PP Transformer
PIN -128 -192 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN -128 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN -128 192 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
PIN 128 64 NONE 8
PINATTR PinName 4
PINATTR SpiceOrder 4
PIN 128 -64 NONE 8
PINATTR PinName 5
PINATTR SpiceOrder 5
