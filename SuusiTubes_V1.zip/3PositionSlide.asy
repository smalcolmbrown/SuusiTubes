Version 4
SymbolType BLOCK
LINE Normal -16 96 32 96
LINE Normal -16 32 32 32
LINE Normal -16 -32 32 -32
LINE Normal -16 -96 32 -96
RECTANGLE Normal -32 -48 -16 -16
RECTANGLE Normal -32 48 -16 16
RECTANGLE Normal -32 -112 -16 -80
RECTANGLE Normal -32 112 -16 80
RECTANGLE Normal -32 -32 -48 -96
TEXT 0 -64 Center 2 1
TEXT 0 0 Center 2 2
TEXT 0 64 Center 2 3
WINDOW 3 0 128 Center 2
WINDOW 0 0 -128 Center 2
SYMATTR Value SET=1
SYMATTR SpiceModel 3PositionSlide
SYMATTR Prefix X
SYMATTR Description 3 Position Slide Switch
PIN 32 -96 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 32 -32 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 32 32 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
PIN 32 96 NONE 8
PINATTR PinName 4
PINATTR SpiceOrder 4
