Version 4
SymbolType CELL
LINE Normal -96 64 -96 32
LINE Normal 96 -32 36 -32
LINE Normal 48 -32 48 32
LINE Normal 40 -24 48 -32
LINE Normal 56 -24 48 -32
LINE Normal 96 32 48 32
LINE Normal 96 32 96 32
LINE Normal 20 -32 16 -32
LINE Normal -60 -32 -64 -32
LINE Normal 0 -32 -44 -32
LINE Normal -32 -32 -32 64
LINE Normal -40 -24 -32 -32
LINE Normal -24 -24 -32 -32
LINE Normal 0 0 0 -32
LINE Normal 96 0 0 0
LINE Normal 96 64 -32 64
LINE Normal -96 16 -96 -32
LINE Normal -80 16 -96 16
LINE Normal -80 -32 -80 16
LINE Normal -96 -96 -96 -48
LINE Normal 28 -16 28 -24 2
LINE Normal -112 -16 28 -16 2
LINE Normal -52 0 -112 0 2
LINE Normal -52 -24 -52 0 2
LINE Normal 96 -64 48 -64
LINE Normal 96 -64 96 -64
LINE Normal 48 -40 48 -64
LINE Normal 56 -48 48 -40
LINE Normal 40 -48 48 -40
LINE Normal 96 -96 -32 -96
LINE Normal 96 -96 96 -96
LINE Normal -32 -40 -32 -96
LINE Normal -24 -48 -32 -40
LINE Normal -40 -48 -32 -40
RECTANGLE Normal -80 -32 -96 -48
RECTANGLE Normal -80 16 -96 32
ARC Normal 36 -40 20 -24 20 -32 36 -32
ARC Normal -44 -40 -60 -24 -60 -32 -44 -32
WINDOW 3 -1 80 Center 0
WINDOW 0 0 -112 Center 0
SYMATTR Value Set=1
SYMATTR Prefix X
SYMATTR SpiceModel StereoJackSocket
SYMATTR Description Stereo Jack Socket
PIN -96 64 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 96 -32 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 96 32 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
PIN 96 -64 NONE 8
PINATTR PinName 4
PINATTR SpiceOrder 4
PIN -112 -16 NONE 8
PINATTR PinName 5
PINATTR SpiceOrder 5
PIN 96 0 NONE 8
PINATTR PinName 6
PINATTR SpiceOrder 6
PIN 96 64 NONE 8
PINATTR PinName 7
PINATTR SpiceOrder 7
PIN 96 -96 NONE 8
PINATTR PinName 8
PINATTR SpiceOrder 8
PIN -112 0 NONE 8
PINATTR PinName 9
PINATTR SpiceOrder 9
PIN -96 -96 NONE 8
PINATTR PinName 10
PINATTR SpiceOrder 10
