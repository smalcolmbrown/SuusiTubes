Version 4
SymbolType BLOCK
LINE Normal 0 64 32 64
LINE Normal 0 0 32 0
LINE Normal 0 -64 32 -64
RECTANGLE Normal -16 -16 0 16
RECTANGLE Normal -16 80 0 48
RECTANGLE Normal -16 -80 0 -48
RECTANGLE Normal -16 0 -32 -64
TEXT 0 -32 Center 2 1
TEXT 0 32 Center 2 2
WINDOW 3 8 -97 Center 2
WINDOW 0 -28 -123 Left 2
SYMATTR Value SET=1
SYMATTR SpiceModel 2PositionSlide
SYMATTR Prefix X
SYMATTR Description SPDT slide switch
PIN 32 -64 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 32 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 32 64 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
