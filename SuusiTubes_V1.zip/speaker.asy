Version 4
SymbolType CELL
LINE Normal 16 -64 0 -32
LINE Normal -32 32 0 32
LINE Normal -32 -32 -32 32
LINE Normal 0 -32 -32 -32
LINE Normal 16 64 0 32
LINE Normal 16 -64 16 64
LINE Normal 0 32 0 -32
LINE Normal -16 -32 -16 -48
LINE Normal -16 32 -16 48
WINDOW 3 29 31 Left 2
WINDOW 0 26 -33 Left 2
SYMATTR Value Speaker
SYMATTR Prefix X
SYMATTR Description Speaker simulation
PIN -16 -48 NONE 8
PINATTR PinName a
PINATTR SpiceOrder 1
PIN -16 48 NONE 8
PINATTR PinName b
PINATTR SpiceOrder 2
